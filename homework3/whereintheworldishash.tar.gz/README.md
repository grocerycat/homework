## This is the first bash script created
### For a practice of git commands
#### Feel free to fork !

