#!/bin/bash
dir=$1
if [ -d $dir ]; then
   cd $dir;
   file=`ls -a`;
  echo $file | sed "s/[A-Z]/&&&/g";
fi
if [ ! -d $dir ]; then
  echo "Not a directory" > printcap3_error.log;
fi

